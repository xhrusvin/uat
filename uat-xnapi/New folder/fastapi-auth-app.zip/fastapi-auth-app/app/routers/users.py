from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.core.security import verify_api_key
from app.models.user import User
from app.schemas.user import UserListResponse, UserResponse

router = APIRouter(prefix="/users", tags=["Users"])


def _user_to_response(user: User) -> UserResponse:
    return UserResponse(
        id=str(user.id),
        email=user.email,
        first_name=user.first_name,
        last_name=user.last_name,
        full_name=user.full_name,
        phone=user.phone,
        is_admin=user.is_admin,
        status=user.status,
        created_at=user.created_at,
    )


# ── READ (list) — excludes admin users ───────────────────────────────────────

@router.get(
    "/",
    response_model=UserListResponse,
    summary="List all non-admin users",
    dependencies=[Depends(verify_api_key)],
)
async def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None, description="Filter by name, email, or phone"),
):
    from beanie.operators import And, Or, RegEx

    if search:
        pattern = f".*{search}.*"
        query = User.find(
            And(
                User.is_admin == False,  # noqa: E712
                Or(
                    RegEx(User.email, pattern, options="i"),
                    RegEx(User.first_name, pattern, options="i"),
                    RegEx(User.last_name, pattern, options="i"),
                    RegEx(User.phone, pattern, options="i"),
                ),
            )
        )
    else:
        query = User.find(User.is_admin == False)  # noqa: E712

    total = await query.count()
    users = await query.skip(skip).limit(limit).to_list()
    return UserListResponse(total=total, users=[_user_to_response(u) for u in users])


# ── READ (single) — blocks access to admin users ─────────────────────────────

@router.get(
    "/{user_id}",
    response_model=UserResponse,
    summary="Get user by ID",
    dependencies=[Depends(verify_api_key)],
)
async def get_user(user_id: str):
    from beanie import PydanticObjectId
    try:
        oid = PydanticObjectId(user_id)
    except Exception:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Invalid user ID")

    user = await User.get(oid)
    if not user or user.is_admin:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return _user_to_response(user)
